Graph Info

20v-3out-4min-355max
	20 vertices
	3 edges out of each node
	capacities range from 4 to 355
	max flow: 368

100v-5out-25min-200max
	100 vertices
	5 edges out of each node
	capacities range from 25 to 200
	max flow: 517
